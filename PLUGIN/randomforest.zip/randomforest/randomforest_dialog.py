import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.model_selection._search")

from PyQt5.QtCore import QStringListModel, Qt, QVariant
from PyQt5.QtGui import QIntValidator
from qgis.core import QgsVectorLayer, QgsFeature, QgsField, QgsProject
from PyQt5.QtWidgets import QDialog, QCheckBox, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QListView, QGridLayout, QPushButton, QMessageBox, QGroupBox, QLineEdit, QSizePolicy, QTableWidget, QTableWidgetItem
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

class RandomForestDialog(QDialog):
    """
    class RandomForest_Spatial Data
    Author : WonHong Lee
    LAB : LSDS
    Date : 2024.07.31 ~ 2024.08.05
    """
    def __init__(self):
        super(RandomForestDialog, self).__init__()
        self.indepCount = 0
        self.ratioPercent = 0
        self.treeValue = 0
        self.mtryValue = 1
        self.plotValue = 0
        self.resultDialog = None
        self.plotDialog = None
        self.tuning = None
        self.init_ui()
        self.setup_connections()
        self.reset_ui()

    def reset_ui(self):
        self.populateShapefiles()
        self.dependentBox.clear()
        self.dependentBox.addItem("", None)
        self.fieldModel.setStringList([])
        self.independentModel.setStringList([])

        self.ratioLine.clear()
        self.treeNumberLine.clear()
        self.mtryLine.clear()

        self.ratioBox.setChecked(False)
        self.treeNumberBox.setChecked(False)
        self.importancePlotCheckBox.setChecked(False)

        self.ratioLine.setEnabled(True)
        self.treeNumberLine.setEnabled(True)
        self.mtryLine.setEnabled(True)
        self.treeNumberLine.setEnabled(True)

        self.indepCount = 0
        self.ratioPercent = 0
        self.treeValue = 1
        self.mtryValue = 1
        self.plotValue = 0
        self.tuning = None

    def onratioTextChanged(self, text):
        try:
            value = int(text)
            if value < 0 or value > 100:
                QMessageBox.warning(self, 'Error', '올바른 숫자를 기입하세요(0 ~ 100).')
                self.ratioLine.clear()
                self.ratioPercent = 0
            else:
                self.ratioPercent = value
        except ValueError:
            if text:
                QMessageBox.warning(self, 'Error', '숫자를 입력하세요.')
                self.ratioLine.clear()
                self.ratioPercent = 0
        
    def onratioChecked(self, state):
        if state == Qt.Checked:
            self.ratioLine.setEnabled(False)
            self.ratioPercent = 70
            self.ratioLine.setText(f"{self.ratioPercent}")
        else:
            self.ratioLine.setEnabled(True)
            self.ratioLine.clear()
            self.ratioPercent = 0
            
    def ontreeTextChanged(self, text):
        try:
            value = int(text)
            if value < 1 or value > 1000:
                QMessageBox.warning(self, 'Error', '올바른 숫자를 기입하세요(10 ~ 1000).')
                self.treeNumberLine.clear()
                self.treeValue = 500
            else:
                self.treeValue = value
        except ValueError:
            if text and self.tuning == False:
                QMessageBox.warning(self, 'Error', '숫자를 입력하세요.')
                self.treeNumberLine.clear()
                self.treeValue = 500

    def ontreeChecked(self, state):
        if state == Qt.Checked:
            self.treeNumberLine.setEnabled(False)
            self.treeValue = 500
            self.treeNumberLine.setText(f"{self.treeValue}")
        else:
            self.treeNumberLine.setEnabled(True)
            self.treeNumberLine.clear()
            self.treeValue = 0

    def onmtryTextChanged(self, text):
        try:
            value = int(text)
            if value < 1 or value > self.indepCount:
                QMessageBox.warning(self, 'Error', '독립변수의 수에 맞추어 입력하세요')
                self.mtryLine.clear()
                self.mtryValue = 1
            else:
                self.mtryValue = value
        except ValueError:
            if text and self.tuning == False:
                QMessageBox.warning(self, 'Error', '숫자를 입력하세요.')
                self.mtryLine.clear()
                self.mtryValue = 1
    
    def ontuningChecked(self, state):
        if state == Qt.Checked:
            self.tuning = True
            self.treeNumberLine.setText(" ")
            self.mtryLine.setText(" ")
            self.treeNumberBox.setChecked(False)
            self.treeNumberBox.setEnabled(False)
            self.treeNumberLine.setEnabled(False)
            self.mtryLine.setEnabled(False)
        else:
            self.tuning = False
            self.treeNumberLine.setEnabled(True)
            self.treeNumberBox.setEnabled(True)
            self.mtryLine.setEnabled(True)
            
    def onplotChecked(self, state):
        if state == Qt.Checked:
            self.plotValue = 1
        else:
            self.plotValue = 0
        
    def setup_connections(self):
        self.targetBox.currentTextChanged.connect(self.updateFieldsAndDependentBox)
        self.inButton.clicked.connect(self.addIndependentVariable)
        self.outButton.clicked.connect(self.removeIndependentValueable)
        self.ratioBox.stateChanged.connect(self.onratioChecked)
        self.ratioLine.textChanged.connect(self.onratioTextChanged)
        self.treeNumberBox.stateChanged.connect(self.ontreeChecked)
        self.treeNumberLine.textChanged.connect(self.ontreeTextChanged)
        self.mtryLine.textChanged.connect(self.onmtryTextChanged)
        self.tuningBox.stateChanged.connect(self.ontuningChecked)
        self.importancePlotCheckBox.stateChanged.connect(self.onplotChecked)
        self.runButton.clicked.connect(self.runRandomForest)
        self.cancelButton.clicked.connect(self.close)        
        
    def init_ui(self):
        self.mainLayout = QVBoxLayout()
        self.selectLayout = QVBoxLayout()
        self.targetLabel = QLabel("Select a Target Layer:")
        self.selectLayout.addWidget(self.targetLabel)
        self.targetBox = QComboBox()
        self.selectLayout.addWidget(self.targetBox)

        self.dependentLabel = QLabel("Dependent Variable:")
        self.selectLayout.addWidget(self.dependentLabel)
        self.dependentBox = QComboBox()
        self.selectLayout.addWidget(self.dependentBox)
        
        self.ratioLayout = QHBoxLayout()
        self.ratioLabel = QLabel("Ratio of Train Set (%):")
        self.ratioLayout.addWidget(self.ratioLabel)
        self.ratioLine = QLineEdit()
        self.ratioLine.setPlaceholderText("0 ~ 100 (%)")
        self.ratioLine.setValidator(QIntValidator(0, 100, self))
        self.ratioLine.setAlignment(Qt.AlignCenter)
        self.ratioLayout.addWidget(self.ratioLine, alignment=Qt.AlignLeft)
        self.ratioLine.setFixedWidth(80)
        self.ratioDefault = QLabel("Default")
        self.ratioLayout.addWidget(self.ratioDefault)
        self.ratioDefault.setFixedWidth(50)
        self.ratioBox = QCheckBox()
        self.ratioLayout.addWidget(self.ratioBox)
        self.selectLayout.addLayout(self.ratioLayout)
                
        self.mainLayout.addLayout(self.selectLayout)
        
        self.fieldLayout = QGridLayout()

        self.fieldLabel = QLabel("Fields")
        self.fieldLayout.addWidget(self.fieldLabel, 0, 0, alignment=Qt.AlignCenter)
        self.fieldView = QListView()
        self.fieldView.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.fieldModel = QStringListModel()
        self.fieldView.setModel(self.fieldModel)
        self.fieldLayout.addWidget(self.fieldView, 1, 0, 2, 1)

        self.inButton = QPushButton(">")
        self.inButton.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        self.inButton.setFixedSize(60, 20)
        self.fieldLayout.addWidget(self.inButton, 1, 1, alignment=Qt.AlignCenter)
        self.outButton = QPushButton("<")
        self.outButton.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        self.outButton.setFixedSize(60, 20)
        self.fieldLayout.addWidget(self.outButton, 2, 1, alignment=Qt.AlignCenter)

        self.independentLabel = QLabel("Independent Variables")
        self.fieldLayout.addWidget(self.independentLabel, 0, 2, alignment=Qt.AlignCenter)
        self.independentView = QListView()
        self.independentView.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.independentModel = QStringListModel()
        self.independentView.setModel(self.independentModel)
        self.fieldLayout.addWidget(self.independentView, 1, 2, 2, 1)
        
        self.mainLayout.addLayout(self.fieldLayout)
        
        self.hyperparameterGroupBox = QGroupBox("Set HyperParameter")
        self.additionGrid = QGridLayout()
        
        self.treeNumberLabel = QLabel("Number of trees")
        self.additionGrid.addWidget(self.treeNumberLabel, 0, 0, alignment=Qt.AlignLeft)
        self.treeNumberLine = QLineEdit()
        self.treeNumberLine.setPlaceholderText("10 ~ 1000")
        self.treeNumberLine.setValidator(QIntValidator(1, 1000, self))
        self.treeNumberLine.setAlignment(Qt.AlignCenter)
        self.additionGrid.addWidget(self.treeNumberLine, 0, 1, alignment=Qt.AlignLeft)
        self.treeNumberLine.setFixedWidth(65)
        
        self.treeNumberDefaultLabel = QLabel("Default")
        self.additionGrid.addWidget(self.treeNumberDefaultLabel, 0, 3, alignment=Qt.AlignLeft)
        self.treeNumberDefaultLabel.setFixedWidth(50)
        self.treeNumberBox = QCheckBox()
        self.additionGrid.addWidget(self.treeNumberBox, 0, 4, alignment=Qt.AlignLeft)
        
        self.mtryLabel = QLabel("Mtry")
        self.additionGrid.addWidget(self.mtryLabel, 0, 5, alignment=Qt.AlignCenter)
        self.mtryLine = QLineEdit()
        self.mtryLine.setValidator(QIntValidator(1, self.indepCount, self))
        self.mtryLine.setAlignment(Qt.AlignCenter)
        self.additionGrid.addWidget(self.mtryLine, 0, 6, alignment=Qt.AlignLeft)
        self.mtryLine.setFixedWidth(35)
        
        self.tuningLabel = QLabel("Hyper Parameter Tuning")
        self.additionGrid.addWidget(self.tuningLabel, 1, 1, 1, 3, alignment=Qt.AlignLeft)
        self.tuningBox = QCheckBox()
        self.additionGrid.addWidget(self.tuningBox, 1, 4, alignment=Qt.AlignLeft)
        
        self.importancePlotLabel = QLabel("Plot Importance")
        self.additionGrid.addWidget(self.importancePlotLabel, 2, 0, alignment=Qt.AlignLeft)
        self.importancePlotCheckBox = QCheckBox()       
        self.additionGrid.addWidget(self.importancePlotCheckBox, 2, 1, alignment=Qt.AlignLeft)
        
        self.hyperparameterGroupBox.setLayout(self.additionGrid)
        self.mainLayout.addWidget(self.hyperparameterGroupBox)
        
        self.buttonLayout = QHBoxLayout()
        self.runButton = QPushButton("Run")
        self.cancelButton = QPushButton("Cancel")
        self.buttonLayout.addStretch()
        self.buttonLayout.addWidget(self.runButton)
        self.buttonLayout.addWidget(self.cancelButton)
        self.runButton.setFixedSize(self.cancelButton.sizeHint())

        self.mainLayout.addLayout(self.buttonLayout)
        self.setLayout(self.mainLayout)
        self.setGeometry(300, 200, 375, 475)
        
    def populateShapefiles(self):
        self.targetBox.clear()
        layers = QgsProject.instance().mapLayers().values()
        valid_layers = [layer for layer in layers if isinstance(layer, QgsVectorLayer) and layer.dataProvider().storageType() == 'ESRI Shapefile']
        if valid_layers:
            self.targetBox.addItem("", None)
            for layer in valid_layers:
                self.targetBox.addItem(layer.name(), layer)
        else:
            self.targetBox.addItem("No shapefile layers available", None)
            
    def updateFieldsAndDependentBox(self):
        self.dependentBox.clear()
        self.dependentBox.addItem("", None)
        self.fieldModel.setStringList([])
        self.independentModel.setStringList([])
        current_layer = self.targetBox.currentData()
        if current_layer:
            numeric_fields = []
            for field in current_layer.fields():
                all_values_numeric = True
                for feature in current_layer.getFeatures():
                    value = feature[field.name()]
                    if not isinstance(value, (int, float, type(None))):
                        all_values_numeric = False
                        break

                if all_values_numeric:
                    numeric_fields.append(field.name())

            if numeric_fields:
                self.fieldModel.setStringList(numeric_fields)
                self.dependentBox.addItems(numeric_fields)
            else:
                self.fieldModel.setStringList(["No numeric fields"])
                self.dependentBox.addItem("No numeric fields available")

    def addIndependentVariable(self):
        selected_indexes = self.fieldView.selectedIndexes()
        if selected_indexes:
            selected_field = selected_indexes[0].data()
            field_list = self.fieldModel.stringList()
            independent_fields = self.independentModel.stringList()
            if selected_field not in independent_fields:
                independent_fields.append(selected_field)
                field_list.remove(selected_field)
                self.independentModel.setStringList(independent_fields)
                self.fieldModel.setStringList(field_list)
                self.indepCount += 1
    
    def removeIndependentValueable(self):
        selected_indexes = self.independentView.selectedIndexes()
        if selected_indexes:
            selected_field = selected_indexes[0].data()
            field_list = self.fieldModel.stringList()
            independent_fields = self.independentModel.stringList()
            if selected_field not in field_list:
                field_list.append(selected_field)
                independent_fields.remove(selected_field)
                self.fieldModel.setStringList(field_list)
                self.independentModel.setStringList(independent_fields)
                self.indepCount -= 1
                
    # def add_layer_with_predictions(self, existing_layer, dependent_field, feature_ids, y_predictions):
    #     layer_name = f"Prediction_{dependent_field}_Layer"
    #     for layer in QgsProject.instance().mapLayers().values():
    #         if layer.name() == layer_name:
    #             QMessageBox.critical(self, "Error", "같은 Layer가 존재합니다.")
    #             return
        
    #     # 새로운 레이어 생성 
    #     new_layer = QgsVectorLayer("Point?crs={}".format(existing_layer.crs().authid()), layer_name, "memory")
    #     new_layer_data_provider = new_layer.dataProvider()

    #     # 기존 레이어의 모든 필드를 새로운 레이어에 추가
    #     new_layer_data_provider.addAttributes(existing_layer.fields())
    #     new_layer.updateFields()

    #     # "RF_Prediction" 필드 추가
    #     new_prediction_field = QgsField(f"RF_Prediction_{layer_name}", QVariant.Double)
    #     new_layer_data_provider.addAttributes([new_prediction_field])
    #     new_layer.updateFields()

    #     # 기존 레이어의 피처 복사 및 예측 결과 추가
    #     for feature_id, prediction in zip(feature_ids, y_predictions):
    #         feature_id = int(feature_id)  # Ensure the feature ID is an integer
    #         feature = existing_layer.getFeature(feature_id)
    #         new_feature = QgsFeature()
    #         new_feature.setGeometry(feature.geometry())
    #         new_feature.setAttributes(feature.attributes() + [prediction])
    #         new_layer_data_provider.addFeature(new_feature)

    #     # 레이어 추가
    #     QgsProject.instance().addMapLayer(new_layer)
    
    # def layer_exists(self, layer_name):
    #     for layer in QgsProject.instance().mapLayers().values():
    #         if layer.name() == layer_name:
    #             return True
    #     return False

    def hyperparameterTuning(self, X_train, y_train):
        ### RandomizedSearchCV (1 ~ 2분 내)
        # n_iter 값 설정
        param_dist = {
        'n_estimators': [100, 300, 500, 700, 900],
        'max_features': ['auto', 'sqrt', 'log2'],
        'max_depth': [None, 10, 20, 30, 40, 50],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
        }
        rf = RandomForestRegressor(random_state=42)
        random_search = RandomizedSearchCV(estimator=rf, param_distributions=param_dist, n_iter=20, cv=3, n_jobs=1, verbose=2, random_state=42)
        random_search.fit(X_train, y_train)
        
        return random_search.best_params_

        ### GridSearchCV 너무 오래 걸림 (5분 이상)
        # param_grid = {
        # 'n_estimators': [100, 200, 300, 400, 500],
        # 'max_features': ['auto', 'sqrt', 'log2'],
        # 'max_depth': [None, 10, 20, 30, 40, 50],
        # 'min_samples_split': [2, 5, 10],
        # 'min_samples_leaf': [1, 2, 4]
        # }
        # rf = RandomForestRegressor(random_state=42)
        # grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, cv=3, n_jobs=1, verbose=2)
        # grid_search.fit(X_train, y_train)
        # return grid_search.best_params_
    
    def runRandomForest(self):
        try:
            current_layer = self.targetBox.currentData()
            if current_layer is None:
                QMessageBox.warning(self, "Error", "Target Layer를 선택하세요")
                return
            dependent_field = self.dependentBox.currentText()
            independent_fields = self.independentModel.stringList()
            if not dependent_field or not independent_fields:
                QMessageBox.warning(self, "Error", "독립변수, 종속변수가 올바르게 선택되었는지 확인하세요")
                return
            if not self.ratioLine.text() and not self.ratioBox.isChecked():
                QMessageBox.warning(self, "Error", "Train 비율을 입력하세요")
                return

            X = []
            y = []
            feature_ids = []
            for feature in current_layer.getFeatures():
                y_value = feature[dependent_field]
                if y_value is None:
                    continue
                y.append(y_value)
                x_row = []
                for field in independent_fields:
                    x_value = feature[field]
                    if x_value is None:
                        x_value = 0
                    x_row.append(x_value)
                X.append(x_row)
                feature_ids.append(feature.id())

            if not X or not y:
                QMessageBox.warning(self, "Error", "독립변수, 종속변수 데이터가 올바른 형식이 아닙니다.")
                return

            X = np.array(X)
            y = np.array(y)
            
            # 데이터 스케일
            # scaler = StandardScaler()
            # X = scaler.fit_transform(X)

            test_size = 1 - (self.ratioPercent / 100)
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)
            
            if self.tuning == True:
                best_params = self.hyperparameterTuning(X_train, y_train)
                self.treeValue = best_params['n_estimators'] # 가지 수
                self.mtryValue = best_params['max_features'] # 최대 Features
                max_depth = best_params['max_depth'] # 가지 뻗는 max 깊이
                min_samples_split = best_params['min_samples_split'] 
                min_samples_leaf = best_params['min_samples_leaf'] # 말단 최소 샘플 개수
            else:
                max_depth = None
                min_samples_split = 2
                min_samples_leaf = 1


            model = RandomForestRegressor(
                n_estimators=self.treeValue, max_features=self.mtryValue,
                max_depth=max_depth, min_samples_split=min_samples_split,
                min_samples_leaf=min_samples_leaf, random_state=42)
            model.fit(X_train, y_train)

            y_prediction = model.predict(X_test)
            mse = mean_squared_error(y_test, y_prediction)
            rmse = np.sqrt(mse)

            feature_importances = model.feature_importances_

            labels = [self.treeValue, self.mtryValue]
            self.showResults(labels, dependent_field, rmse, self.plotValue, feature_importances, independent_fields)
            
            # layer_name = f"Prediction_{dependent_field}_Layer"
            # if not self.layer_exists(layer_name):
            #     self.add_layer_with_predictions(current_layer, feature_ids, y_prediction, dependent_field)
            # else:
            #     QMessageBox.critical(self, "Error", f"A layer with the same name ({layer_name}) already exists.")
            # self.add_layer_with_predictions(current_layer, dependent_field, feature_ids, y_prediction)
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
            return

    def showResults(self, labels, dependent_field, rmse, plotValue, feature_importances, independent_fields):
        self.resultDialog = RFResults(labels, dependent_field, rmse)
        self.resultDialog.show()  # 비모달 방식으로 열기

        if plotValue == 1:
            self.plotDialog = ImportancePlot(independent_fields, feature_importances)
            self.plotDialog.show()  # 비모달 방식으로 열기


class RFResults(QDialog):
    def __init__(self, labels, dependent_field, rmse):
        super(RFResults, self).__init__()
        self.labels = labels
        self.dependent_field = dependent_field
        self.rmse = rmse
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        results = QHBoxLayout(self)
        tree_label = QLabel(f"Number of Trees: {self.labels[0]}")
        results.addWidget(tree_label)
        mtry_label = QLabel(f"Number of Features: {self.labels[1]}")
        results.addWidget(mtry_label)
        
        layout.addLayout(results)
        
        rmse_table = QTableWidget(self)
        rmse_table.setRowCount(1)
        rmse_table.setColumnCount(2)
        rmse_table.setHorizontalHeaderLabels(["Variable","RMSE"])
        
        rmse_table.setItem(0, 0, QTableWidgetItem(self.dependent_field))
        rmse_table.setItem(0, 1, QTableWidgetItem(f"{self.rmse:.4f}"))
        layout.addWidget(rmse_table)
        
        self.setLayout(layout)
        self.setWindowTitle("Random Forest Results")
        self.setGeometry(700, 200, 250, 200)

class ImportancePlot(QDialog):
    def __init__(self, feature_names, feature_importances):
        super(ImportancePlot, self).__init__()
        self.feature_importances = feature_importances
        self.feature_names = feature_names
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        sorted_indices = np.argsort(self.feature_importances)
        sorted_feature_importances = self.feature_importances[sorted_indices]
        sorted_feature_names = [self.feature_names[i] for i in sorted_indices]
        
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.barh(sorted_feature_names, sorted_feature_importances, align='center')
        ax.set_xlabel('Feature Importance')
        ax.set_ylabel('Features')
        ax.set_title('Feature Importance Plot')

        canvas = FigureCanvas(fig)
        layout.addWidget(canvas)

        self.setLayout(layout)
        self.setWindowTitle("Feature Importance")
        self.setGeometry(720, 320, 700, 525)
