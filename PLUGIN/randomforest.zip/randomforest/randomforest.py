from PyQt5.QtCore import QCoreApplication, QSettings, QTranslator, qVersion
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QAction
import os.path
from .randomforest_dialog import RandomForestDialog  # 변경된 경로를 확인하세요

class RandomForest:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr(u"&RandomForest")
        self.toolbar = self.iface.addToolBar(u"RandomForest")
        self.toolbar.setObjectName(u"RandomForest")
        self.dlg = None

    def tr(self, message):
        return QCoreApplication.translate("RandomForest", message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None,
    ):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        self.plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(self.plugin_dir, 'icon', 'random_forest.png')
        self.add_action(
            icon_path,
            text=self.tr(u"RandomForest"),
            callback=self.run,
            parent=self.iface.mainWindow()
        )
    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u"&RandomForest"), action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def run(self):
        if self.dlg is None:
            self.dlg = RandomForestDialog()
        else:
            self.dlg.reset_ui()
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
        self.dlg.exec_()
